run the short cut. a console app will open.

use internet browser and go to the https location in the console  
Eg paste this in browser -> https://localhost:5001